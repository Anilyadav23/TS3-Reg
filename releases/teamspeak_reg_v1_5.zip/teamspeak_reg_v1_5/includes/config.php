<?php

/**
 * @author Anthony Lawrence <freelancer@anthonylawrence.me.uk>
 * @copyright Copyright (c) 2011, Anthony Lawrence
 *
 * Released as is with no guarantees and all that usual stuff.
 *
 * This copyright must remain intact at all times.
 * @version 1.5
 */

/******************************************************************************/
/*********** SETTINGS FOR TS3 BOT - MODIFY THESE TO MEET YOUR NEEDS ***********/
/******************************************************************************/

// Basic website info.
define("WEB_NAME", "__ENTER__NAME__HERE__"); // The name of the website.
define("TIMEZONE", "Europe/London"); // The timezone to use.  See http://php.net/manual/en/timezones.php

// Set the database information.
define("SQL_HOST", "localhost"); // The IP or location of the database server (include port if needed).
define("SQL_USER", "teamspeak"); // The username for the database server. 
define("SQL_PASS", ""); // The password for the database server.
define("SQL_DB", "teamspeak"); // The name of the database which we're using!
define("SQL_PREFIX", "tsbot_"); // Enter a lowercase prefix if using a shared database for the tables.

// What authentication method are we using for this system?
define("AUTHENTICATION_FILE", "default.php"); // Just the filename from the auth folder.

// Teamspeak server settings.
define("TS_USER", "TSBOT"); // The query user that this script will use.
define("TS_PASS", "qwerty"); // The password that the query user users.
define("TS_HOST", "teamspeak.xyz.co.uk");
define("TS_PORT", "9987"); // The SERVER port.
define("TS_QPORT", "10011"); // The QUERY port.

// Teamspeak account settings.
define("TS_MAX_ID", 5); // The maximum number of IDs a user can have at any one time.
define("TS_SA_GROUP", 6); // The group ID of server admins.
define("TS_ME_GROUP", 7); // The group ID of the normal members.

/******************************************************************************/
/*** END OF SETTINGS - ONLY MODIFY BELOW HERE IF YOU KNOW WHAT YOU'RE DOING ***/
/******************************************************************************/

?>
